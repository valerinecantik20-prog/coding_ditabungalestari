# Online Python compiler (interpreter)
# Write and run Python online using this editor.

print("What does the Visualize button do?")
nilai_tugas = int(input("Masukkan nilai tugas: "))
uts = int(input("Masukkan nilai UTS: "))
uas = int(input("Masukkan nilai UAS: "))
kehadiran_mahasiswa = int(input("Masukkan nilai kehadiran (%): "))

nilai_akhir = (20 / 100 * nilai_tugas) + (30 / 100 * uts) + (50 / 100 * uas)

print("\n===== HASIL =====")
print("Nilai akhir =", nilai_akhir)
print("Kehadiran =", kehadiran_mahasiswa, "%")

if nilai_akhir >= 85 and kehadiran_mahasiswa >= 90:
    print("Predikat: A")
elif nilai_akhir >= 75 and kehadiran_mahasiswa >= 80:
    print("Predikat: B")
elif nilai_akhir >= 65 and kehadiran_mahasiswa >= 75:
    print("Predikat: C")
else:
    print("Predikat: D")

